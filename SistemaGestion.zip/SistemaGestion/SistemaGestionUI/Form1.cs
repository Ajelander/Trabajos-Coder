using SistemaGestionBusiness;
using SistemaGestionEntities;

namespace SistemaGestionUI
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            List<Usuario> usuarios = UsuarioBusiness.GetUsuarios();
            dataGridView1.AutoGenerateColumns = true;
            dataGridView1.DataSource = usuarios;
        }
    }
}