﻿using SistemaGestionBusiness;
using SistemaGestionEntities;
Console.WriteLine("Hello, World!");

   
List<Usuario> usuarios = new List<Usuario>();
usuarios = UsuarioBusiness.GetUsuarios();


Venta venta = new Venta();
/*venta.Id = 1;
venta.Comentarios = "";
venta.IdUsuario = 2;

*/
VentaBusiness.crearVenta(venta);
  
