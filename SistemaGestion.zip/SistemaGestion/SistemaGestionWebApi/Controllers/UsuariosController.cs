﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using SistemaGestionBusiness;
using SistemaGestionEntities;
namespace SistemaGestionWebApi.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class UsuariosController : ControllerBase
    {
        [HttpGet(Name = "GetUsuarios")]
        public IEnumerable<Usuario> Get()
        {
            return UsuarioBusiness.GetUsuarios()
            .ToArray();
        }

        [HttpGet("Traer", Name = "TraerUsuario")]
        public Usuario GetUsuario(int id)
        {
            return UsuarioBusiness.obtenerUsuario(id)[0];
        }

        [HttpPost(Name = "CrearUsuario")]
        public void crearUsuario([FromBody]Usuario usuario)
        {
            UsuarioBusiness.crearUsuario(usuario);
        }


        [HttpPut(Name = "ModificarUsuario")]
        public void Put([FromBody] Usuario usuario)
        {
            UsuarioBusiness.modificarUsuario(usuario);
        }

        
        [HttpGet("Nombre", Name = "TraerNombre")]
        
        public Usuario GetNombre([FromBody]string nombre)
        {
           return UsuarioBusiness.obtenerUsuarioPorNombre(nombre);
        }


        [HttpGet("Login", Name = "InicioDeSesion")]
        public bool login(string username, string password)
        {
            return UsuarioBusiness.login(username, password);

        }

        [HttpDelete(Name ="EliminarUsuario")]
        public void delete([FromBody] int id)
        {
            UsuarioBusiness.eliminarUsuario(id);
        }
    }
}
