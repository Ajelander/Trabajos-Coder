﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using SistemaGestionBusiness;
using SistemaGestionEntities;

namespace SistemaGestionWebApi.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ProductoVendidoController : ControllerBase
    {
        [HttpGet(Name = "GetProductosVendidos")]
        public IEnumerable<ProductoVendido> Get()
        {
            return ProductoVendidoBusiness.obtenerProductos()
            .ToArray();
        }

        [HttpPost(Name = "CargarProductoVendido")]
        public void CargarProductoVendido([FromBody] ProductoVendido productoVendido)
        {
            ProductoVendidoBusiness.crearProductoVendido(productoVendido);


        }

        [HttpDelete(Name = "EliminarProductoVendido")]
        public void EliminarProductoVendido([FromBody] int idProductoVendido)
        {
            ProductoVendidoBusiness.eliminarProductoVendido(idProductoVendido);


        }
    }
}
