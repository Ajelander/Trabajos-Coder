﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using SistemaGestionBusiness;
using SistemaGestionEntities;
using System.Xml.Linq;

namespace SistemaGestionWebApi.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ProductoController : ControllerBase
    {

        


        [HttpGet(Name = "TraerProductos")]
        public IEnumerable<Producto> Get()
        {
            return ProductoBusiness.obtenerProductos()
            .ToArray();
        }

        [HttpPost(Name = "crearProducto")]
        public void Post([FromBody] Producto producto)
        {
            ProductoBusiness.crearProducto(producto);
            //como valido los datos?
        }

        [HttpPut(Name = "ModificarProducto")]
        public void Put([FromBody] Producto producto)
        {
            ProductoBusiness.modificarProducto(producto);
        }

        [HttpDelete(Name = "EliminarProducto")]

        public void Delete([FromBody] int id)
        {

            ProductoVendidoBusiness.eliminarProductoVendido2(id);
            ProductoBusiness.eliminarProducto(id);
            
            //deberia eliminar usando el id de producto, como hago eso?
            //modifico el producoVendido data?
            


        }

        //tengo que hacer Traer Productos, Traer Productos vendidos Traer Ventas
        

    }
}
