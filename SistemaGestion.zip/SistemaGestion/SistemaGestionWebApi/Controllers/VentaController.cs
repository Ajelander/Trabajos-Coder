﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using SistemaGestionBusiness;
using SistemaGestionEntities;

namespace SistemaGestionWebApi.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class VentasController : ControllerBase
    {
        [HttpGet(Name = "TraerVentas")]
        public IEnumerable<Venta> Get()
        {
            return VentaBusiness.obtenerVentas()
            .ToArray();
        }

        [HttpPost(Name = "CargarVenta")]
        public void CargarVenta([FromBody] List<ProductoVendido> productos)//, [FromBody] int idUsuario)
        {
            //tengo que cargar la venta
            Venta venta = new Venta();
            venta.Comentarios = "";
            venta.Id = 0;
            venta.IdUsuario = 1;

            VentaBusiness.crearVenta(venta);


            //primero cargar los produtos en productos vendidos
            int i = 0;


            while (i < productos.Count)
            {
                //cargar el producto i en la tabla
                ProductoVendidoBusiness.crearProductoVendido(productos[i]);


                //borrar restar el stock de productos, y si da 0 eliminarlo
                int idProducto = Convert.ToInt32(productos[i].IdProducto);
                int stockARestar = productos[i].Stock;
                Producto productoAModificar = (ProductoBusiness.obtenerProducto(idProducto))[0];

                //actualizo stock
                int stockActual = productoAModificar.Stock;
                productoAModificar.Stock = stockActual - stockARestar;

                if (productoAModificar.Stock > 0)
                {
                    ProductoBusiness.modificarProducto(productoAModificar);
                }
                else
                {
                    ProductoBusiness.eliminarProducto(Convert.ToInt32(productoAModificar.Id));
                }

                i++;
            }
                
            
            


        }

        [HttpDelete(Name = "ElliminarVenta")]
        public void eliminarVenta([FromBody] int id)
        {
            VentaBusiness.eliminarVenta(id);


        }




    }
}
