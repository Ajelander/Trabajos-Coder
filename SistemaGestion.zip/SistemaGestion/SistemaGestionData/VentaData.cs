﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using SistemaGestionEntities;

namespace SistemaGestionData
{
    public class VentaData
    {
        public static List<Venta> obtenerVenta(int id)
        {
            /*lo hago con una lista para que de esta forma, si se agregan mas usuarios
            de los que deberian me doy cuenta, y de esa forma corroboro mejor que ande bien
             */
            List<Venta> lista = new List<Venta>();
            string connectionString = @"Server=DESKTOP-D2B7V16;DataBase=SistemaGestion;Trusted_Connection=True";
            string query = "SELECT Id,Comentarios,IdUSuario FROM Venta Where Id=@id";
            //crear comando

            try
            {
                using (SqlConnection conexion = new SqlConnection(connectionString))
                {
                    conexion.Open();
                    using (SqlCommand comando = new SqlCommand(query, conexion))
                    {

                        //pasar los parámetros
                        var parametro = new SqlParameter();
                        parametro.ParameterName = "id";
                        parametro.SqlDbType = SqlDbType.BigInt;
                        parametro.Value = id;

                        comando.Parameters.Add(parametro);

                        using (SqlDataReader dataReader = comando.ExecuteReader())
                        {

                            if (dataReader.HasRows)
                            {


                                while (dataReader.Read())
                                {

                                    var venta = new Venta();
                                    venta.Id = Convert.ToInt64(dataReader["Id"]);

                                    venta.Comentarios = dataReader["Comentarios"].ToString();

                                    venta.IdUsuario = Convert.ToInt64(dataReader["IdUsuario"]);



                                    lista.Add(venta);
                                }
                            }
                            conexion.Close();
                        }
                    }
                }
                return lista;

            }
            catch (Exception ex)
            {

                return null;
            }



        }

        public static List<Venta> listarVentas()
        {


            List<Venta> lista = new List<Venta>();
            string connectionString = @"Server=DESKTOP-D2B7V16;DataBase=SistemaGestion;Trusted_Connection=True";
            string query = "SELECT Id,Comentarios,IdUSuario FROM Venta";


            try
            {
                using (SqlConnection conexion = new SqlConnection(connectionString))
                {
                    conexion.Open();
                    using (SqlCommand comando = new SqlCommand(query, conexion))
                    {


                        using (SqlDataReader dataReader = comando.ExecuteReader())
                        {

                            if (dataReader.HasRows)
                            {

                                while (dataReader.Read())
                                {

                                    var venta = new Venta();
                                    venta.Id = Convert.ToInt64(dataReader["Id"]);

                                    venta.Comentarios = dataReader["Comentarios"].ToString();

                                    venta.IdUsuario = Convert.ToInt64(dataReader["IdUsuario"]);
                                    


                                    lista.Add(venta);
                                }
                            }
                            conexion.Close();
                        }
                    }
                }
                return lista;

            }
            catch (Exception ex)
            {

                return null;
            }



        }

        public static void crearVenta(Venta ventaCrear)
        {
            string connectionString = @"Server=DESKTOP-D2B7V16;DataBase=SistemaGestion;Trusted_Connection=True";
            string query = "INSERT INTO VENTA ( Comentarios, IdUsuario)" +
                           " VALUES ( @Comentarios, @IdUsuario)";
            try
            {
                using (SqlConnection conexion = new SqlConnection(connectionString))
                {
                    conexion.Open();
                    using (SqlCommand cmd = new SqlCommand(query, conexion))
                    {

                        
                        cmd.Parameters.Add(new SqlParameter("Id", SqlDbType.BigInt) { Value = ventaCrear.Id });
                        cmd.Parameters.Add(new SqlParameter("Comentarios", SqlDbType.VarChar) { Value = ventaCrear.Comentarios });
                        cmd.Parameters.Add(new SqlParameter("IdUsuario", SqlDbType.BigInt) { Value = ventaCrear.IdUsuario });

                        cmd.ExecuteNonQuery();

                    }
                    conexion.Close();
                }

            }
            catch (Exception)
            {

                throw;
            }

        }


        public static void eliminarVenta(int id)
        {
            
            string connectionString = @"Server=DESKTOP-D2B7V16;DataBase=SistemaGestion;Trusted_Connection=True";
            string query = "DELETE FROM Venta Where Id=@id";

            try
            {
                using (SqlConnection conexion = new SqlConnection(connectionString))
                {
                    conexion.Open();
                    using (SqlCommand cmd = new SqlCommand(query, conexion))
                    {
                        cmd.Parameters.Add(new SqlParameter("Id", SqlDbType.BigInt) { Value = id });

                        
                        cmd.ExecuteNonQuery();
                    }

                    conexion.Close();
                }
            }
            catch (Exception)
            {

                throw;
            }

        }


        public static void modificarVenta(Venta ventaAModificar)
        {

            string connectionString = @"Server=DESKTOP-D2B7V16;DataBase=SistemaGestion;Trusted_Connection=True";
            string query = "UPDATE Venta SET " +
                " Comentarios=@Comentarios, IdUsuario=@IdUsuario" +
                " WHERE Id=@Id";

            try
            {
                using (SqlConnection conexion = new SqlConnection(connectionString))
                {
                    conexion.Open();
                    using (SqlCommand cmd = new SqlCommand(query, conexion))
                    {

                        cmd.Parameters.Add(new SqlParameter("Id", SqlDbType.BigInt) { Value = ventaAModificar.Id });
                        cmd.Parameters.Add(new SqlParameter("Comentarios", SqlDbType.VarChar) { Value = ventaAModificar.Comentarios });
                        cmd.Parameters.Add(new SqlParameter("IdUsuario", SqlDbType.BigInt) { Value = ventaAModificar.IdUsuario });

                        cmd.ExecuteNonQuery();
                    }
                    conexion.Close();
                }
            }
            catch (Exception ex)
            {

                throw;
            }
        }
    }
}
