﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using SistemaGestionEntities;

namespace SistemaGestionData
{
    public class ProductoData
    {
        public static List<Producto> ObtenerProducto(int id)
        {
            /*lo hago con una lista para que de esta forma, si se agregan mas usuarios
            de los que deberian me doy cuenta, y de esa forma corroboro mejor que ande bien
             */
            List<Producto> lista = new List<Producto>();
            string connectionString = @"Server=DESKTOP-D2B7V16;DataBase=SistemaGestion;Trusted_Connection=True";
            string query = "SELECT Id,Descripciones,Costo,PrecioVenta,Stock,IdUsuario FROM Producto Where Id=@id";
            //crear comando

            try
            {
                using (SqlConnection conexion = new SqlConnection(connectionString))
                {
                    conexion.Open();
                    using (SqlCommand comando = new SqlCommand(query, conexion))
                    {

                        //pasar los parámetros
                        var parametro = new SqlParameter();
                        parametro.ParameterName = "id";
                        parametro.SqlDbType = SqlDbType.BigInt;
                        parametro.Value = id;

                        comando.Parameters.Add(parametro);

                        using (SqlDataReader dataReader = comando.ExecuteReader())
                        {
                            
                            if (dataReader.HasRows)
                            {

                                while (dataReader.Read())
                                {
                                    var Producto = new Producto();
                                    Producto.Id = Convert.ToInt32(dataReader["Id"]);
                                    Producto.Descripcion = dataReader["Descripciones"].ToString();
                                    Producto.Costo = Convert.ToInt32(dataReader["Costo"]);
                                    Producto.PrecioVenta = Convert.ToInt32(dataReader["PrecioVenta"]);
                                    Producto.Stock = Convert.ToInt32(dataReader["Stock"]);
                                    Producto.IdUsuario = Convert.ToInt32(dataReader["IdUsuario"]);


                                    lista.Add(Producto);
                                }
                            }
                            conexion.Close();
                        }
                    }
                }
                return lista;

            }
            catch (Exception ex)
            {

                return null;
            }



        }

        public static List<Producto> ListarProductos()
        {
           
            List<Producto> lista = new List<Producto>();
            string connectionString = @"Server=DESKTOP-D2B7V16;DataBase=SistemaGestion;Trusted_Connection=True";
            string query = "SELECT Id,Descripciones,Costo,PrecioVenta,Stock,IdUsuario FROM Producto";
            //crear comando

            try
            {
                using (SqlConnection conexion = new SqlConnection(connectionString))
                {
                    conexion.Open();
                    using (SqlCommand comando = new SqlCommand(query, conexion))
                    {
                                           

                        using (SqlDataReader dataReader = comando.ExecuteReader())
                        {

                            if (dataReader.HasRows)
                            {

                                while (dataReader.Read())
                                {
                                    var Producto = new Producto();
                                    Producto.Id = Convert.ToInt32(dataReader["Id"]);
                                    Producto.Descripcion = dataReader["Descripciones"].ToString();
                                    Producto.Costo = Convert.ToInt32(dataReader["Costo"]);
                                    Producto.PrecioVenta = Convert.ToInt32(dataReader["PrecioVenta"]);
                                    Producto.Stock = Convert.ToInt32(dataReader["Stock"]);
                                    Producto.IdUsuario = Convert.ToInt32(dataReader["IdUsuario"]);


                                    lista.Add(Producto);
                                }
                            }
                            conexion.Close();
                        }
                    }
                }
                return lista;

            }
            catch (Exception ex)
            {

                return null;
            }



        }

        public static void crearProducto(Producto productoCrear)
        {
            string connectionString = @"Server=DESKTOP-D2B7V16;DataBase=SistemaGestion;Trusted_Connection=True";
            string query = "INSERT INTO PRODUCTO (Descripciones,Costo,PrecioVenta,Stock,IdUsuario)" +
                           " VALUES( @Descripciones, @Costo, @PrecioVenta, @Stock, @IdUsuario)";
            try
            {
                using (SqlConnection conexion = new SqlConnection(connectionString))
                {
                    conexion.Open();
                    using (SqlCommand cmd = new SqlCommand(query, conexion))
                    {
                        
                        cmd.Parameters.Add(new SqlParameter("Descripciones", SqlDbType.VarChar) { Value = productoCrear.Descripcion });
                        cmd.Parameters.Add(new SqlParameter("Costo", SqlDbType.VarChar) { Value = productoCrear.Costo });
                        cmd.Parameters.Add(new SqlParameter("PrecioVenta", SqlDbType.VarChar) { Value = productoCrear.PrecioVenta });
                        cmd.Parameters.Add(new SqlParameter("Stock", SqlDbType.VarChar) { Value = productoCrear.Stock });
                        cmd.Parameters.Add(new SqlParameter("IdUsuario", SqlDbType.VarChar) { Value = productoCrear.IdUsuario });

                        cmd.ExecuteNonQuery();

                    }
                    conexion.Close();
                }

            }
            catch (Exception)
            {

                throw;
            }

        }


        public static void eliminarProducto(int id)
        {
            List<Producto> lista = new List<Producto>();
            string connectionString = @"Server=DESKTOP-D2B7V16;DataBase=SistemaGestion;Trusted_Connection=True";
            string query = "DELETE FROM Producto Where Id=@id";

            try
            {
                using (SqlConnection conexion = new SqlConnection(connectionString))
                {
                    conexion.Open();
                    using (SqlCommand cmd = new SqlCommand(query, conexion))
                    {
                        cmd.Parameters.Add(new SqlParameter("Id", SqlDbType.Int) { Value = id });

                        //execute non query porque no devuelve nada
                        cmd.ExecuteNonQuery();
                    }

                    conexion.Close();
                }
            }
            catch (Exception)
            {

                throw;
            }

        }

        public static void modificarProducto(Producto ProductoModificar)
        {

            string connectionString = @"Server=DESKTOP-D2B7V16;DataBase=SistemaGestion;Trusted_Connection=True";
            string query = "UPDATE Producto SET " +
                "Descripciones=@Descripciones, Costo = @Costo, PrecioVenta=@PrecioVenta, Stock=@Stock, IdUsuario= @IdUsuario" +
                " WHERE Id=@Id";

            try
            {
                using (SqlConnection conexion = new SqlConnection(connectionString))
                {
                    conexion.Open();
                    using (SqlCommand cmd = new SqlCommand(query, conexion))
                    {
                        cmd.Parameters.Add(new SqlParameter("Id", SqlDbType.Int) { Value = ProductoModificar.Id });
                        cmd.Parameters.Add(new SqlParameter("Descripciones", SqlDbType.VarChar) { Value = ProductoModificar.Descripcion });
                        cmd.Parameters.Add(new SqlParameter("Costo", SqlDbType.Int) { Value = ProductoModificar.Costo });
                        cmd.Parameters.Add(new SqlParameter("PrecioVenta", SqlDbType.Int) { Value = ProductoModificar.PrecioVenta });
                        cmd.Parameters.Add(new SqlParameter("Stock", SqlDbType.Int) { Value = ProductoModificar.Stock });
                        cmd.Parameters.Add(new SqlParameter("IdUsuario", SqlDbType.Int) { Value = ProductoModificar.IdUsuario });

                        cmd.ExecuteNonQuery();
                    }
                    conexion.Close();
                }
            }
            catch (Exception ex)
            {

                throw;
            }
        }
    }
}
