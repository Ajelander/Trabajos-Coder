﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using SistemaGestionEntities;

namespace SistemaGestionData
{
    public class ProductoVendidoData
    {
        public static List<ProductoVendido> obtenerProductoVendido(int id)
        {
            /*lo hago con una lista para que de esta forma, si se agregan mas usuarios
            de los que deberian me doy cuenta, y de esa forma corroboro mejor que ande bien
             */
            List<ProductoVendido> lista = new List<ProductoVendido>();
            string connectionString = @"Server=DESKTOP-D2B7V16;DataBase=SistemaGestion;Trusted_Connection=True";
            string query = "SELECT Id,IdProducto,Stock,IdVenta FROM ProductoVendido Where Id=@id";
            //crear comando

            try
            {
                using (SqlConnection conexion = new SqlConnection(connectionString))
                {
                    conexion.Open();
                    using (SqlCommand comando = new SqlCommand(query, conexion))
                    {

                        //pasar los parámetros
                        var parametro = new SqlParameter();
                        parametro.ParameterName = "id";
                        parametro.SqlDbType = SqlDbType.BigInt;
                        parametro.Value = id;

                        comando.Parameters.Add(parametro);

                        using (SqlDataReader dataReader = comando.ExecuteReader())
                        {

                            if (dataReader.HasRows)
                            {

                                
                                while (dataReader.Read())
                                {
                                    
                                    var productoVendidos = new ProductoVendido();
                                    productoVendidos.Id = Convert.ToInt32(dataReader["Id"]);
                                    
                                    productoVendidos.IdProducto = Convert.ToInt64(dataReader["IdProducto"]);
                                    
                                    productoVendidos.Stock = Convert.ToInt32(dataReader["Stock"]);
                                    productoVendidos.IdVenta = Convert.ToInt32(dataReader["IdVenta"]);


                                    
                                    lista.Add(productoVendidos);
                                }
                            }
                            conexion.Close();
                        }
                    }
                }
                return lista;

            }
            catch (Exception ex)
            {

                return null;
            }



        }

        public static List<ProductoVendido> listarProductosVendidos()
        {
            

            List<ProductoVendido> lista = new List<ProductoVendido>();
            string connectionString = @"Server=DESKTOP-D2B7V16;DataBase=SistemaGestion;Trusted_Connection=True";
            string query = "SELECT Id,IdProducto,Stock,IdVenta FROM ProductoVendido";
            

            try
            {
                using (SqlConnection conexion = new SqlConnection(connectionString))
                {
                    conexion.Open();
                    using (SqlCommand comando = new SqlCommand(query, conexion))
                    {


                        using (SqlDataReader dataReader = comando.ExecuteReader())
                        {

                            if (dataReader.HasRows)
                            {
                                
                                while (dataReader.Read())
                                {
                                    
                                    var productoVendido = new ProductoVendido();
                                    productoVendido.Id = Convert.ToInt32(dataReader["Id"]);

                                    productoVendido.IdProducto = Convert.ToInt64(dataReader["IdProducto"]);

                                    productoVendido.Stock = Convert.ToInt32(dataReader["Stock"]);
                                    productoVendido.IdVenta = Convert.ToInt32(dataReader["IdVenta"]);

                                    
                                    lista.Add(productoVendido);
                                }
                            }
                            conexion.Close();
                        }
                    }
                }
                return lista;

            }
            catch (Exception ex)
            {

                return null;
            }



        }

        public static void crearProductoVendido(ProductoVendido productoVendidoCrear)
        {
            string connectionString = @"Server=DESKTOP-D2B7V16;DataBase=SistemaGestion;Trusted_Connection=True";
            string query = "INSERT INTO PRODUCTOVENDIDO (IdProducto,Stock,IdVenta)" +
                           " VALUES (@IdProducto, @Stock, @IdVenta)";
            try
            {
                using (SqlConnection conexion = new SqlConnection(connectionString))
                {
                    conexion.Open();
                    using (SqlCommand cmd = new SqlCommand(query, conexion))
                    {

                        //cmd.Parameters.Add(new SqlParameter("Id", SqlDbType.Int) { Value = productoVendidoCrear.Id });
                        cmd.Parameters.Add(new SqlParameter("IdProducto", SqlDbType.Int) { Value = productoVendidoCrear.IdProducto });
                        cmd.Parameters.Add(new SqlParameter("Stock", SqlDbType.Int) { Value = productoVendidoCrear.Stock });
                        cmd.Parameters.Add(new SqlParameter("IdVenta", SqlDbType.Int) { Value = productoVendidoCrear.IdVenta });

                        cmd.ExecuteNonQuery();

                    }
                    conexion.Close();
                }

            }
            catch (Exception)
            {

                throw;
            }

        }

        public static void eliminarProductoVendido(int id)
        {
            
            string connectionString = @"Server=DESKTOP-D2B7V16;DataBase=SistemaGestion;Trusted_Connection=True";
            string query = "DELETE FROM ProductoVendido Where Id=@id";

            try
            {
                using (SqlConnection conexion = new SqlConnection(connectionString))
                {
                    conexion.Open();
                    using (SqlCommand cmd = new SqlCommand(query, conexion))
                    {
                        cmd.Parameters.Add(new SqlParameter("Id", SqlDbType.Int) { Value = id });

                        //execute non query porque no devuelve nada
                        cmd.ExecuteNonQuery();
                    }

                    conexion.Close();
                }
            }
            catch (Exception)
            {

                throw;
            }

        }


        public static void modificarProductoVendido(ProductoVendido ProductoVendidoModificar)
        {

            string connectionString = @"Server=DESKTOP-D2B7V16;DataBase=SistemaGestion;Trusted_Connection=True";
            string query = "UPDATE ProductoVendido SET " +
                " Stock=@Stock, IdProducto=@IdProducto, IdVenta=@IdVenta" +
                " WHERE Id=@Id";

            try
            {
                using (SqlConnection conexion = new SqlConnection(connectionString))
                {
                    conexion.Open();
                    using (SqlCommand cmd = new SqlCommand(query, conexion))
                    {
                        cmd.Parameters.Add(new SqlParameter("Id", SqlDbType.Int) { Value = ProductoVendidoModificar.Id });
                        cmd.Parameters.Add(new SqlParameter("Stock", SqlDbType.Int) { Value = ProductoVendidoModificar.Stock });
                        cmd.Parameters.Add(new SqlParameter("IdProducto", SqlDbType.Int) { Value = ProductoVendidoModificar.IdProducto });
                        
                        cmd.Parameters.Add(new SqlParameter("IdVenta", SqlDbType.Int) { Value = ProductoVendidoModificar.IdVenta });

                        cmd.ExecuteNonQuery();
                    }
                    conexion.Close();
                }
            }
            catch (Exception ex)
            {

                throw;
            }
        }
    }
}
