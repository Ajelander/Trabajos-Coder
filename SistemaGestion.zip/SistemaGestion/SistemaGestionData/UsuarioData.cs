﻿using SistemaGestionEntities;
using System.Data;
using System.Data.SqlClient;

namespace SistemaGestionData
{
    public static class UsuarioData
    {

        private static string connectionString = @"Server=DESKTOP-D2B7V16;DataBase=SistemaGestion;
                                        Trusted_Connection=True";
        public static List<Usuario> getUsuarios()
        {
            List<Usuario> usuarios = new List<Usuario>();

             
             string query = "SELECT Id,Nombre,Apellido,NombreUsuario,Contraseña,Mail FROM Usuario";

            try
            {
                using(SqlConnection conexion = new SqlConnection(connectionString))
                {
                    conexion.Open();
                    using (SqlCommand comando = new SqlCommand(query, conexion))
                    {
                        using( SqlDataReader dr = comando.ExecuteReader())
                        {
                            if (dr.HasRows)
                            {
                                while (dr.Read())
                                {
                                    var usuario = new Usuario();
                                    usuario.Id = Convert.ToInt32(dr["Id"]);
                                    usuario.Nombre = dr["Nombre"].ToString();
                                    usuario.Apellido = dr["Apellido"].ToString();
                                    usuario.NombreUsuario = dr["NombreUsuario"].ToString();
                                    usuario.Contraseña = dr["Contraseña"].ToString();
                                    usuario.Mail = dr["Mail"].ToString();

                                    usuarios.Add(usuario);
                                }
                            }
                        }
                    }
                }

                return usuarios;
            }
            catch (Exception ex)
            {

                throw;
            }
        }

        public static List<Usuario> ObtenerUsuario(int id)
        {
            /*lo hago con una lista para que de esta forma, si se agregan mas usuarios
            de los que deberian me doy cuenta, y de esa forma corroboro mejor que ande bien
             */
            List<Usuario> lista = new List<Usuario>();
            string query = "SELECT Id,Nombre,Apellido,NombreUsuario,Contraseña,Mail FROM Usuario Where Id=@id";
            //crear comando

            try
            {
                using (SqlConnection conexion = new SqlConnection(connectionString))
                {
                    conexion.Open();
                    using (SqlCommand comando = new SqlCommand(query, conexion))
                    {

                        //pasar los parámetros
                        var parametro = new SqlParameter();
                        parametro.ParameterName = "id";
                        parametro.SqlDbType = SqlDbType.BigInt;
                        parametro.Value = id;

                        comando.Parameters.Add(parametro);

                        using (SqlDataReader dataReader = comando.ExecuteReader())
                        {
                            Console.Write("LLego");


                            if (dataReader.HasRows)
                            {

                                while (dataReader.Read())
                                {
                                    var Usuario = new Usuario();
                                    Usuario.Id = Convert.ToInt32(dataReader["Id"]);
                                    Usuario.Nombre = dataReader["Nombre"].ToString();
                                    Usuario.Apellido = dataReader["Apellido"].ToString();
                                    Usuario.NombreUsuario = dataReader["NombreUsuario"].ToString();
                                    Usuario.Contraseña = dataReader["Contraseña"].ToString();
                                    Usuario.Mail = dataReader["Mail"].ToString();


                                    lista.Add(Usuario);
                                }
                            }
                            conexion.Close();
                        }
                    }
                }
                return lista;

            }
            catch (Exception ex)
            {

                return null;
            }



        }

        public static void crearUsuario(Usuario usuarioCrear)
        {
            string query = "INSERT INTO USUARIO (Nombre,Apellido,NombreUsuario,Contraseña,Mail)" +
                           " VALUES( @Nombre, @Apellido, @NombreUsuario, @Contraseña, @Mail)";
            try
            {
                using (SqlConnection conexion = new SqlConnection(connectionString))
                {
                    conexion.Open();
                    using (SqlCommand cmd = new SqlCommand(query, conexion))
                    {
                        // cmd.Parameters.Add(new SqlParameter("Id", SqlDbType.Int) { Value = usuarioCrear.Id });
                        cmd.Parameters.Add(new SqlParameter("Nombre", SqlDbType.VarChar) { Value = usuarioCrear.Nombre });
                        cmd.Parameters.Add(new SqlParameter("Apellido", SqlDbType.VarChar) { Value = usuarioCrear.Apellido });
                        cmd.Parameters.Add(new SqlParameter("NombreUsuario", SqlDbType.VarChar) { Value = usuarioCrear.NombreUsuario });
                        cmd.Parameters.Add(new SqlParameter("Contraseña", SqlDbType.VarChar) { Value = usuarioCrear.Contraseña });
                        cmd.Parameters.Add(new SqlParameter("Mail", SqlDbType.VarChar) { Value = usuarioCrear.Mail });

                        cmd.ExecuteNonQuery();

                    }
                    conexion.Close();
                }

            }
            catch (Exception)
            {

                throw;
            }

        }

        public static void eliminarUsuario(int id)
        {
            List<Usuario> lista = new List<Usuario>();
            string query = "DELETE FROM Usuario Where Id=@id";

            try
            {
                using (SqlConnection conexion = new SqlConnection(connectionString))
                {
                    conexion.Open();
                    using (SqlCommand cmd = new SqlCommand(query, conexion))
                    {
                        cmd.Parameters.Add(new SqlParameter("Id", SqlDbType.Int) { Value = id });

                        //execute non query porque no devuelve nada
                        cmd.ExecuteNonQuery();
                    }

                    conexion.Close();
                }
            }
            catch (Exception)
            {

                throw;
            }

        }

        public static void modificarUsuario(Usuario usuarioModificar)
        {

            string query = "UPDATE Usuario SET " +
                "Nombre=@Nombre, Apellido = @Apellido, NombreUsuario=@NombreUsuario, Contraseña=@Contraseña, Mail= @Mail" +
                " WHERE Id=@Id";

            try
            {
                using (SqlConnection conexion = new SqlConnection(connectionString))
                {
                    conexion.Open();
                    using (SqlCommand cmd = new SqlCommand(query, conexion))
                    {
                        cmd.Parameters.Add(new SqlParameter("Id", SqlDbType.Int) { Value = usuarioModificar.Id });
                        cmd.Parameters.Add(new SqlParameter("Nombre", SqlDbType.VarChar) { Value = usuarioModificar.Nombre });
                        cmd.Parameters.Add(new SqlParameter("Apellido", SqlDbType.VarChar) { Value = usuarioModificar.Apellido });
                        cmd.Parameters.Add(new SqlParameter("NombreUsuario", SqlDbType.VarChar) { Value = usuarioModificar.NombreUsuario });
                        cmd.Parameters.Add(new SqlParameter("Contraseña", SqlDbType.VarChar) { Value = usuarioModificar.Contraseña });
                        cmd.Parameters.Add(new SqlParameter("Mail", SqlDbType.VarChar) { Value = usuarioModificar.Mail });

                        cmd.ExecuteNonQuery();
                    }
                    conexion.Close();
                }
            }
            catch (Exception ex)
            {

                throw;
            }
        }

        public static Usuario obtenerUsuarioPorNombre(string nombre)
        {
            Usuario usuario = new Usuario();
            string query = "SELECT Id,Nombre,Apellido,NombreUsuario,Contraseña,Mail FROM Usuario Where Nombre=@nombre";
            //crear comando

            try
            {
                using (SqlConnection conexion = new SqlConnection(connectionString))
                {
                    conexion.Open();
                    using (SqlCommand comando = new SqlCommand(query, conexion))
                    {

                        //pasar los parámetros
                        var parametro = new SqlParameter();
                        parametro.ParameterName = "nombre";
                        parametro.SqlDbType = SqlDbType.VarChar;
                        parametro.Value = nombre;

                        comando.Parameters.Add(parametro);

                        using (SqlDataReader dataReader = comando.ExecuteReader())
                        {
                            Console.Write("LLego");


                            if (dataReader.HasRows)
                            {

                                while (dataReader.Read())
                                {

                                    usuario.Id = Convert.ToInt32(dataReader["Id"]);
                                    usuario.Nombre = dataReader["Nombre"].ToString();
                                    usuario.Apellido = dataReader["Apellido"].ToString();
                                    usuario.NombreUsuario = dataReader["NombreUsuario"].ToString();
                                    usuario.Contraseña = dataReader["Contraseña"].ToString();
                                    usuario.Mail = dataReader["Mail"].ToString();


                                    
                                }
                            }
                            conexion.Close();
                        }
                    }
                }
                return usuario;

            }
            catch (Exception ex)
            {

                return null;
            }

        }

        

    }


}