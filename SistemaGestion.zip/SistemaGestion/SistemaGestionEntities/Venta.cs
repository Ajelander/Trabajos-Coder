﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SistemaGestionEntities
{
    public class Venta
    {
        private string _comentarios;
        public long Id { get; set; }

        public string Comentarios
        {
            get { return this._comentarios; }
            set { this._comentarios = value; }

        }

        public long IdUsuario { get; set; }

        public Venta() { 
            
            this._comentarios = string.Empty;
            this.Id = 0;
            this.Comentarios = string.Empty;
            this.IdUsuario = 0;
        }

        public Venta(string comentarios, long id, long idUsuario)
        {
            this._comentarios = comentarios;
            this.Id = id;
            this.IdUsuario = idUsuario;
        }
    }
}
