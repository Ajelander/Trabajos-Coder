﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SistemaGestionEntities
{
    public class Producto
    {
        private long _id;
        private string _descripcion;
        private int _costo;
        private int _precioVenta;
        private int _stock;
        private int _idUsuario;

        public Producto()
        {
            this._id = 0;
            this._descripcion = string.Empty;
            this._costo = 0;
            this._precioVenta = 0;
            this._stock = 0;
            this._idUsuario = 0;
        }

        public Producto(long id, string descripcion, int costo, int precioVenta, int stock, int idUsuario)
        {
            Id = id;
            Descripcion = descripcion;
            Costo = costo;
            PrecioVenta = precioVenta;
            Stock = stock;
            IdUsuario = idUsuario;
            
        }

        public long Id{
            get { return this._id; }
            set { this._id = value; }
        }
        public string Descripcion { 
            get { return  this._descripcion; }
            set { _descripcion = value; }

        }

        public int Costo
        {
            get { return this._costo; }
            set { this._costo = value; }
        }

        public int PrecioVenta
        {
            get { return this._precioVenta; }
            set { this._precioVenta = value; }
        }

        public int Stock
        {
            get { return this._stock; }
            set { this._stock = value; }
        }

        public int IdUsuario
        {
            get { return this._idUsuario; }
            set { this._idUsuario = value; }
        }

    }
}
