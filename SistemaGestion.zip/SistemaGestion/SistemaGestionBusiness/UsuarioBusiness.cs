﻿using SistemaGestionEntities;
using SistemaGestionData;
namespace SistemaGestionBusiness
{
    public static class UsuarioBusiness
    {
        public static List<Usuario> GetUsuarios()
        {
            return UsuarioData.getUsuarios();
        }

        public static List<Usuario> obtenerUsuario(int id)
        {
            return UsuarioData.ObtenerUsuario(id);
        }

        public static List<Usuario> obtenerUsuarios(int id)
        {
            return UsuarioData.getUsuarios();
        }

        public static void crearUsuario(Usuario usuario)
        {
            UsuarioData.crearUsuario(usuario);
        }

        public static void eliminarUsuario(int id)
        {
            UsuarioData.eliminarUsuario(id);
        }

        public static void modificarUsuario(Usuario usuario)
        {
            UsuarioData.modificarUsuario(usuario);
        }
        
    }
}