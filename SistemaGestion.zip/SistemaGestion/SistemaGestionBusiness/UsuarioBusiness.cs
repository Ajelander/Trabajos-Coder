﻿using SistemaGestionEntities;
using SistemaGestionData;
namespace SistemaGestionBusiness
{
    public static class UsuarioBusiness
    {
        public static List<Usuario> GetUsuarios()
        {
            return UsuarioData.getUsuarios();
        }

        public static List<Usuario> obtenerUsuario(int id)
        {
            return UsuarioData.ObtenerUsuario(id);
        }

        public static Usuario obtenerUsuarioPorNombre(string nombre)
        {
            return UsuarioData.obtenerUsuarioPorNombre(nombre);
        }


        public static List<Usuario> obtenerUsuarios()
        {
            return UsuarioData.getUsuarios();
        }

        public static void crearUsuario(Usuario usuario)
        {
            UsuarioData.crearUsuario(usuario);
        }

        public static void eliminarUsuario(int id)
        {
            UsuarioData.eliminarUsuario(id);
        }

        public static void modificarUsuario(Usuario usuario)
        {
            UsuarioData.modificarUsuario(usuario);
        }

        public static bool login(string nombreUsuario, string Contraseña)
        {
            List<Usuario> lista = new List<Usuario>();
            bool inicioExitoso = false;

            try
            {
                lista = UsuarioData.getUsuarios();
                for (int i = 0; i < lista.Count; i++)
                {
                    if ((lista[i].NombreUsuario == nombreUsuario)  && (lista[i].Contraseña == Contraseña))
                    {
                        inicioExitoso = true;
                        break;
                    }
                }
                return inicioExitoso;
            }
            catch (Exception)
            {

                throw;
            }
        }
        
    }
}