﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using SistemaGestionEntities;
using SistemaGestionData;
namespace SistemaGestionBusiness
{
    public static class ProductoBusiness
    {
        public static List<Producto> obtenerProducto(int id)
        {
            return ProductoData.ObtenerProducto(id);
        }

        public static List<Producto> obtenerProductos(int id)
        {
            return ProductoData.ListarProductos();
        }

        public static void crearProducto(Producto producto)
        {
            ProductoData.crearProducto(producto);
        }

        public static void eliminarProducto(int id)
        {
            ProductoData.eliminarProducto(id);
        }

        public static void modificarProducto(Producto producto)
        {
            ProductoData.modificarProducto(producto);
        }
    }
}
