﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using SistemaGestionData;
using SistemaGestionEntities;

namespace SistemaGestionBusiness
{
    public class VentaBusiness
    {
        public static List<Venta> obtenerVenta(int id)
        {
            return VentaData.obtenerVenta(id);
        }

        public static List<Venta> obtenerVentas()
        {
            return VentaData.listarVentas();
        }

        public static void crearVenta(Venta venta)
        {
            VentaData.crearVenta(venta);
        }

        public static void eliminarVenta(int id)
        {
            VentaData.eliminarVenta(id);
        }

        public static void modificarVenta(Venta venta)
        {
            VentaData.modificarVenta(venta);
        }
    }
}
