﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using SistemaGestionData;
using SistemaGestionEntities;

namespace SistemaGestionBusiness
{
    internal class VentaBusiness
    {
        public static List<Venta> obtenerProducto(int id)
        {
            return VentaData.obtenerVenta(id);
        }

        public static List<Venta> obtenerProductos()
        {
            return VentaData.listarVentas();
        }

        public static void crearProductoVendido(Venta venta)
        {
            VentaData.crearVenta(venta);
        }

        public static void eliminarProductoVendido(int id)
        {
            VentaData.eliminarVenta(id);
        }

        public static void modificarProductoVendido(Venta venta)
        {
            VentaData.modificarVenta(venta);
        }
    }
}
