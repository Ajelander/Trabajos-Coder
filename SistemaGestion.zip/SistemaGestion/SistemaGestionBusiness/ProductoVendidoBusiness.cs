﻿using SistemaGestionData;
using SistemaGestionEntities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using SistemaGestionData;

namespace SistemaGestionBusiness
{
    public class ProductoVendidoBusiness
    {
        public static List<ProductoVendido> obtenerProducto(int id)
        {
            return ProductoVendidoData.obtenerProductoVendido(id);
        }

        public static List<ProductoVendido> obtenerProductos()
        {
            return ProductoVendidoData.listarProductosVendidos();
        }

        public static void crearProductoVendido(ProductoVendido productoVendido)
        {
            ProductoVendidoData.crearProductoVendido(productoVendido);
        }

        public static void eliminarProductoVendido(int id)
        {
            ProductoVendidoData.eliminarProductoVendido(id);
        }

        public static void eliminarProductoVendido2(int id)
        {
            ProductoVendidoData.eliminarProductoVendido2(id);
        }

        public static void modificarProductoVendido(ProductoVendido productoVendido)
        {
            ProductoVendidoData.modificarProductoVendido(productoVendido);
        }
    }
}
